﻿using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Text;
using ukolnicek.model;

namespace ukolnicek.Data
{
    public class ApplicationDbContext : IdentityDbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options) : base(options)
        { }
        public DbSet<ukol> ukoly { get; set; }
        public DbSet <uzivatel> uzivatele { get; set; }
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {


           modelBuilder.Entity<ukol>()
                    .HasOne(ma => ma.zadavatel)
                    .WithMany(m => m.zadaneukoly)
                    .HasForeignKey(p=>p.giverid)
                    .OnDelete(DeleteBehavior.Restrict);
                   
            
            modelBuilder.Entity<ukol>()
                .HasOne(ma => ma.plnitel)
                .WithMany(a => a.plneneukoly)
                .HasForeignKey(p => p.receiverid)
                .OnDelete(DeleteBehavior.Restrict);
        }
    }
}
