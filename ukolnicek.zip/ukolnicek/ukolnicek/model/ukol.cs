﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace ukolnicek.model
{
    public class ukol
    {
        [Key]
        public int id { get; set; }
        public string name { get; set; }
        public bool done { get; set; }

        public string giverid { get; set; }
        
        [ForeignKey("giverid")]
        public uzivatel  zadavatel { get; set; }
        public string receiverid { get; set; }
        [ForeignKey("receiverid")]
        public uzivatel plnitel { get; set; }
    }
}
